*PADS-LIBRARY-PART-TYPES-V9*

S10B-PADSS-1_LF__SN_ S10BPADSS1LFSN I CON 7 1 0 0 0
TIMESTAMP 2026.08.08.17.55.26
"Mouser Part Number" 306-S10BPADSS1LFSN
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/JST-Commercial/S10B-PADSS-1LFSN?qs=QpmGXVUTftHMWc%2FRltCpiA%3D%3D
"Manufacturer_Name" JST (JAPAN SOLDERLESS TERMINALS)
"Manufacturer_Part_Number" S10B-PADSS-1(LF)(SN)
"Description" JST (JAPAN SOLDERLESS TERMINALS) - S10B-PADSS-1(LF)(SN) - CONNECTOR, HEADER, 10POS, 2ROW, 2MM
"Datasheet Link" http://www.jst-mfg.com/product/pdf/eng/ePAD.pdf
"Geometry.Height" 10.5mm
GATE 1 10 0
S10B-PADSS-1_LF__SN_
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
622023/1805092/2.50/10/4/Connector
