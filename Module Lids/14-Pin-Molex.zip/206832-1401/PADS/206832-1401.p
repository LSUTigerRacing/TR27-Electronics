*PADS-LIBRARY-PART-TYPES-V9*

206832-1401 2068321401 I CON 7 1 0 0 0
TIMESTAMP 2026.07.15.01.52.45
"Mouser Part Number" 538-206832-1401
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/206832-1401?qs=EBDBlbfErPx%252BJNkwruVlaw%3D%3D
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 206832-1401
"Description" Headers & Wire Housings Micro-Fit Plus Vert HDR ASSY 2X7 Tin Lu
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/206832-1401.pdf
"Geometry.Height" 9.91mm
GATE 1 14 0
206832-1401
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14

*END*
*REMARK* SamacSys ECAD Model
4628357/1805092/2.50/14/4/Connector
