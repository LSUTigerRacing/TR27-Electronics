*PADS-LIBRARY-PART-TYPES-V9*

B24B-PADSS-1F_LF__SN_ B24BPADSS1FLFSN I CON 7 1 0 0 0
TIMESTAMP 2026.07.15.01.56.05
"Mouser Part Number" 306-B24BPADSS1FLFSN
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/JST-Commercial/B24B-PADSS-1FLFSN?qs=cIziFXvMxOWbuCJVsv9Qaw%3D%3D
"Manufacturer_Name" JST (JAPAN SOLDERLESS TERMINALS)
"Manufacturer_Part_Number" B24B-PADSS-1F(LF)(SN)
"Description" JST PAD Series, Series Number B24B, 2mm Pitch 24 Way 2 Row Straight PCB Header, Through Hole Termination, 3A
"Datasheet Link" http://www.jst-mfg.com/product/pdf/eng/ePAD.pdf
"Geometry.Height" 10mm
GATE 1 25 0
B24B-PADSS-1F_LF__SN_
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15
16 0 U 16
17 0 U 17
18 0 U 18
19 0 U 19
20 0 U 20
21 0 U 21
22 0 U 22
23 0 U 23
24 0 U 24
25 0 U 25

*END*
*REMARK* SamacSys ECAD Model
406992/1805092/2.50/25/4/Connector
