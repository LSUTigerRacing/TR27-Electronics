*PADS-LIBRARY-PART-TYPES-V9*

215760-1005 215760-YY05 I CON 7 1 0 0 0
TIMESTAMP 2026.07.15.01.50.05
"Mouser Part Number" 538-215760-1005
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/215760-1005?qs=pBJMDPsKWf0f86XBp9JaAQ%3D%3D
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 215760-1005
"Description" Micro-Fit+ Right-Angle Header, 3.00mm Pitch, Single Row, 5 Circuits,  UL 94V-0, Glow-Wire Capable, Black
"Datasheet Link" https://www.molex.com/pdm_docs/sd/2157601002_sd.pdf
"Geometry.Height" 5.87mm
GATE 1 5 0
215760-1005
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5

*END*
*REMARK* SamacSys ECAD Model
15432849/1805092/2.50/5/2/Connector
