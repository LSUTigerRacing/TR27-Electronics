*PADS-LIBRARY-PART-TYPES-V9*

S8B-PH-K-S_LF__SN_ SHDRRA8W50P0X200_1X8_1790X760X480P I CON 7 1 0 0 0
TIMESTAMP 2026.07.15.02.09.37
"Mouser Part Number" 306-S8BPHKSLFSN
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/JST-Commercial/S8B-PH-K-SLFSN?qs=QpmGXVUTftFnYhnPf%252Bz1wg%3D%3D
"Manufacturer_Name" JST (JAPAN SOLDERLESS TERMINALS)
"Manufacturer_Part_Number" S8B-PH-K-S(LF)(SN)
"Description" JST PH Series, Series Number S8B, 2mm Pitch 8 Way 1 Row Right Angle PCB Header, Through Hole Termination, 2A
"Datasheet Link" http://www.jst-mfg.com/product/pdf/eng/ePH.pdf
"Geometry.Height" 4.8mm
GATE 1 8 0
S8B-PH-K-S_LF__SN_
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8

*END*
*REMARK* SamacSys ECAD Model
407180/1805092/2.50/8/3/Connector
